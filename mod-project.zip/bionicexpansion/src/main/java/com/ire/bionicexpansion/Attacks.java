package com.ire.bionicexpansion;

import com.ire.bionicexpansion.entity.BionicMob;
import com.ire.bionicexpansion.entity.EnergyBlast;
import com.ire.bionicexpansion.entity.ModEntities;
import com.ire.bionicexpansion.entity.VehicleEntity;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.List;

/** Attacks and effects shared by the mobs, bosses and swords. All of them only run on the server. */
public final class Attacks {
    private Attacks() {
    }

    /** True if `source` should not hurt `target` (itself, its own team, its own vehicle). */
    public static boolean isFriendly(Entity source, Entity target) {
        if (source == null || target == null) return false;
        if (source == target) return true;
        if (source instanceof BionicMob && target instanceof BionicMob) return true;
        if (target instanceof VehicleEntity && target.hasPassenger(source)) return true;
        return source.getVehicle() == target;
    }

    /** Fires an energy blast from the shooter towards a point. */
    public static void shoot(LivingEntity shooter, Vec3 point, ItemStack look, float damage, float speed, float explosion) {
        if (!(shooter.level() instanceof ServerLevel server)) return;
        Vec3 from = new Vec3(shooter.getX(), shooter.getEyeY() - 0.3, shooter.getZ());
        Vec3 dir = point.subtract(from);
        if (dir.lengthSqr() < 1.0E-4) return;
        dir = dir.normalize();
        Vec3 start = from.add(dir.scale(shooter.getBbWidth() * 0.6 + 0.6));
        EnergyBlast blast = new EnergyBlast(ModEntities.ENERGY_BLAST.get(), server);
        blast.setOwner(shooter);
        blast.setItem(look);
        blast.setDamage(damage);
        blast.setExplosion(explosion);
        blast.setPos(start.x, start.y, start.z);
        blast.setDeltaMovement(dir.scale(speed));
        server.addFreshEntity(blast);
        server.playSound(null, shooter.getX(), shooter.getY(), shooter.getZ(), SoundEvents.BLAZE_SHOOT, SoundSource.HOSTILE, 1f, 1.5f);
    }

    /** Fires an energy blast straight where the shooter is looking. */
    public static void shootForward(LivingEntity shooter, ItemStack look, float damage, float speed, float explosion) {
        Vec3 eye = shooter.getEyePosition();
        shoot(shooter, eye.add(shooter.getLookAngle().scale(20)), look, damage, speed, explosion);
    }

    /** Damages and launches everything around the source. Returns how many things were hit. */
    public static int slam(LivingEntity source, double radius, float damage, double lift, int rgb) {
        if (!(source.level() instanceof ServerLevel server)) return 0;
        List<LivingEntity> hit = server.getEntitiesOfClass(LivingEntity.class, source.getBoundingBox().inflate(radius),
                e -> e.isAlive() && !isFriendly(source, e));
        for (LivingEntity e : hit) {
            e.hurt(source instanceof Player p ? source.damageSources().playerAttack(p) : source.damageSources().mobAttack(source), damage);
            Vec3 push = e.position().subtract(source.position());
            push = push.lengthSqr() < 1.0E-4 ? Vec3.ZERO : push.normalize().scale(1.4);
            e.setDeltaMovement(push.x, lift, push.z);
            e.hurtMarked = true;
        }
        server.sendParticles(ParticleTypes.EXPLOSION, source.getX(), source.getY() + 0.2, source.getZ(), 6,
                radius / 2, 0.2, radius / 2, 0);
        ring(server, source.position().add(0, 0.2, 0), radius, rgb, 48);
        server.playSound(null, source.getX(), source.getY(), source.getZ(), SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 2f, 0.5f);
        return hit.size();
    }

    /** Gives every living thing nearby (except friends of the source) an effect. */
    public static void affectNearby(LivingEntity source, double radius, MobEffectInstance effect) {
        if (!(source.level() instanceof ServerLevel server)) return;
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, source.getBoundingBox().inflate(radius),
                x -> x.isAlive() && !isFriendly(source, x))) {
            e.addEffect(new MobEffectInstance(effect));
        }
    }

    // ---------- particles ----------

    public static DustParticleOptions dust(int rgb, float size) {
        return new DustParticleOptions(new Vector3f(((rgb >> 16) & 0xFF) / 255f, ((rgb >> 8) & 0xFF) / 255f, (rgb & 0xFF) / 255f), size);
    }

    /** A burst of coloured dust around a point. */
    public static void burst(ServerLevel server, Vec3 at, int rgb, int count, double spread) {
        server.sendParticles(dust(rgb, 1.5f), at.x, at.y, at.z, count, spread, spread, spread, 0.02);
    }

    /** A flat ring of coloured dust. */
    public static void ring(ServerLevel server, Vec3 centre, double radius, int rgb, int points) {
        DustParticleOptions d = dust(rgb, 2.0f);
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2 * i / points;
            server.sendParticles(d, centre.x + Math.cos(a) * radius, centre.y, centre.z + Math.sin(a) * radius, 1, 0, 0, 0, 0);
        }
    }

    /** A straight line of coloured dust between two points (for dashes and beams). */
    public static void line(ServerLevel server, Vec3 from, Vec3 to, int rgb) {
        DustParticleOptions d = dust(rgb, 1.2f);
        int steps = (int) Math.max(2, from.distanceTo(to) * 3);
        for (int i = 0; i <= steps; i++) {
            Vec3 p = from.lerp(to, i / (double) steps);
            server.sendParticles(d, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0);
        }
    }
}
