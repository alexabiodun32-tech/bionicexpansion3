package com.ire.bionicexpansion;

import com.ire.bionicexpansion.entity.ModEntities;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Bionic's Chaos: Expansion. Needs Bionic's Ultimate Chaos (Mod 1) and GeckoLib. */
@Mod(BionicExpansion.MODID)
public class BionicExpansion {
    public static final String MODID = "bionicexpansion";

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN_TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.literal("Bionic's Chaos: Expansion"))
                    .icon(() -> new ItemStack(ModItems.ULTIMATE_PICKAXE.get()))
                    .displayItems((params, output) ->
                            ModItems.ITEMS.getEntries().forEach(e -> {
                                if (e.get() != ModItems.ENERGY_CHARGE.get()) {
                                    output.accept(e.get());
                                }
                            }))
                    .build());

    public BionicExpansion(IEventBus modBus) {
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        TABS.register(modBus);
    }
}
