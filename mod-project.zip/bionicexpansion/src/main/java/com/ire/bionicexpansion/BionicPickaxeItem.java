package com.ire.bionicexpansion;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * A Bionic pickaxe. Each one has some abilities built in, and more can be added
 * with upgrade modules (stored on the item, so they survive smithing upgrades).
 */
public class BionicPickaxeItem extends PickaxeItem {
    public static final String POWER_UNTIL = "bionic_power_until";
    public static final int POWER_TICKS = 200;      // 10 seconds
    public static final int POWER_COOLDOWN = 600;   // 30 seconds

    /** What the pickaxe does while held. */
    public enum HeldEffect { NONE, FIRE, VOID, ULTIMATE }

    private final Set<PickAbility> builtIn;
    private final HeldEffect heldEffect;
    private final boolean foil;

    public BionicPickaxeItem(BionicTier tier, float attackDamage, Properties props,
                             Set<PickAbility> builtIn, HeldEffect heldEffect, boolean foil) {
        super(tier, props.attributes(DiggerItem.createAttributes(tier, attackDamage, -2.8f)));
        this.builtIn = builtIn.isEmpty() ? EnumSet.noneOf(PickAbility.class) : EnumSet.copyOf(builtIn);
        this.heldEffect = heldEffect;
        this.foil = foil;
    }

    public boolean hasBuiltIn(PickAbility ability) {
        return builtIn.contains(ability);
    }

    /** True if this stack is a Bionic pickaxe with the ability, built in or upgraded. */
    public static boolean has(ItemStack stack, PickAbility ability) {
        if (!(stack.getItem() instanceof BionicPickaxeItem pick)) return false;
        return pick.hasBuiltIn(ability) || isUpgraded(stack, ability);
    }

    public static boolean isUpgraded(ItemStack stack, PickAbility ability) {
        return data(stack).getBoolean(ability.key());
    }

    public static void addUpgrade(ItemStack stack, PickAbility ability) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putBoolean(ability.key(), true));
    }

    public static boolean isPowered(ItemStack stack, Level level) {
        return data(stack).getLong(POWER_UNTIL) > level.getGameTime();
    }

    private static CompoundTag data(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!has(stack, PickAbility.POWER)) {
            return InteractionResultHolder.pass(stack);
        }
        if (!level.isClientSide) {
            long until = level.getGameTime() + POWER_TICKS;
            CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putLong(POWER_UNTIL, until));
            player.getCooldowns().addCooldown(this, POWER_COOLDOWN);
            player.displayClientMessage(Component.literal("POWER MODE!").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), true);
            level.playSound(null, player.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1f, 1.6f);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (selected && !level.isClientSide && entity instanceof LivingEntity living && living.tickCount % 20 == 0) {
            switch (heldEffect) {
                case FIRE -> effect(living, new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 60, 0, true, false, true));
                case VOID -> effect(living, new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, true, false, true));
                case ULTIMATE -> {
                    effect(living, new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, true, false, true));
                    effect(living, new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 60, 0, true, false, true));
                    effect(living, new MobEffectInstance(MobEffects.DIG_SPEED, 60, 2, true, false, true));
                }
                default -> { }
            }
        }
        super.inventoryTick(stack, level, entity, slot, selected);
    }

    private static void effect(LivingEntity living, MobEffectInstance instance) {
        living.addEffect(instance);
    }

    public HeldEffect heldEffect() {
        return heldEffect;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return foil || super.isFoil(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        for (PickAbility ability : PickAbility.values()) {
            if (hasBuiltIn(ability)) {
                tip.add(Component.literal("• " + ability.title).withStyle(ChatFormatting.AQUA));
            } else if (isUpgraded(stack, ability)) {
                tip.add(Component.literal("• " + ability.title + " (upgrade)").withStyle(ChatFormatting.GREEN));
            }
        }
        switch (heldEffect) {
            case FIRE -> tip.add(Component.literal("Fire resistance while held").withStyle(ChatFormatting.GOLD));
            case VOID -> tip.add(Component.literal("Night vision while held").withStyle(ChatFormatting.DARK_PURPLE));
            case ULTIMATE -> tip.add(Component.literal("Night vision, fire resistance and Haste while held").withStyle(ChatFormatting.GOLD));
            default -> { }
        }
        if (has(stack, PickAbility.VEIN) || has(stack, PickAbility.POWER)) {
            tip.add(Component.literal(has(stack, PickAbility.POWER)
                    ? "Right-click for Power Mode" : "Crouch + mine an ore to vein mine").withStyle(ChatFormatting.GRAY));
        }
        tip.add(Component.literal("Add upgrades: hold a module, pickaxe in your other hand, right-click")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
