package com.ire.bionicexpansion;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Swords themed on the mobs and bosses. Each has an on-hit effect and a right-click power. */
public class BionicSwordItem extends SwordItem {
    public enum Power {
        MUTANT("Mutant Cleaver", "Hits weaken and knock back", "Right-click: roar that blasts mobs away", 0x9BE05A, 80),
        PLASMA("Plasma Sword", "Hits crackle with energy", "Right-click: fire a plasma bolt", 0x3CE8FF, 12),
        ALIEN("Alien Saber", "Hits make enemies float", "Right-click: teleport-dash and turn invisible", 0x3CFFB0, 60),
        SPEED("Speed Blade", "Super fast swings, Speed II while held", "Right-click: lightning dash forward", 0xFFD23C, 40),
        TITAN("Titan Hammer", "Hits slow and launch enemies", "Right-click: ground slam", 0xFF8A2A, 100),
        GUARDIAN("Guardian Blade", "Hits shock enemies", "Right-click: energy shield (Resistance + absorption)", 0xFF2A2A, 400),
        KING("Alien King's Scepter", "Hits make enemies glow and float", "Right-click: lift every enemy around you", 0xB43CFF, 160),
        QUANTUM("Quantum Blade", "Hits wither and can warp enemies away", "Right-click: quantum blast volley", 0x3CE8FF, 100);

        public final String title;
        public final String onHit;
        public final String onUse;
        public final int color;
        public final int cooldown;

        Power(String title, String onHit, String onUse, int color, int cooldown) {
            this.title = title;
            this.onHit = onHit;
            this.onUse = onUse;
            this.color = color;
            this.cooldown = cooldown;
        }
    }

    private final Power power;

    public BionicSwordItem(BionicTier tier, int attackDamage, float attackSpeed, Power power, Properties props) {
        super(tier, props.attributes(SwordItem.createAttributes(tier, attackDamage, attackSpeed)));
        this.power = power;
    }

    // ---------- on hit ----------

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker.level() instanceof ServerLevel server) {
            Attacks.burst(server, new Vec3(target.getX(), target.getY(0.6), target.getZ()), power.color, 14, 0.4);
            switch (power) {
                case MUTANT -> {
                    target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
                    target.knockback(1.5, attacker.getX() - target.getX(), attacker.getZ() - target.getZ());
                }
                case PLASMA -> server.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY(0.6), target.getZ(),
                        20, 0.3, 0.5, 0.3, 0.3);
                case ALIEN -> target.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 25, 1));
                case SPEED -> server.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY(0.6), target.getZ(),
                        15, 0.3, 0.5, 0.3, 0.4);
                case TITAN -> {
                    target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
                    target.setDeltaMovement(target.getDeltaMovement().add(0, 0.6, 0));
                    target.hurtMarked = true;
                }
                case GUARDIAN -> server.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY(0.6), target.getZ(),
                        25, 0.4, 0.6, 0.4, 0.4);
                case KING -> {
                    target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
                    target.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 30, 2));
                }
                case QUANTUM -> {
                    target.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));
                    if (attacker.getRandom().nextFloat() < 0.25f) {
                        Vec3 before = target.position();
                        for (int i = 0; i < 8; i++) {
                            double x = target.getX() + attacker.getRandom().nextInt(13) - 6;
                            double z = target.getZ() + attacker.getRandom().nextInt(13) - 6;
                            if (target.randomTeleport(x, target.getY() + 4, z, true)) break;
                        }
                        Attacks.line(server, before.add(0, 1, 0), target.position().add(0, 1, 0), power.color);
                    }
                }
            }
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    // ---------- right-click power ----------

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel server)) {
            return InteractionResultHolder.success(stack);
        }
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        switch (power) {
            case MUTANT -> {
                Attacks.slam(player, 4, 5f, 0.6, power.color);
                sound(server, player, SoundEvents.RAVAGER_ROAR, 0.9f);
            }
            case PLASMA -> Attacks.shootForward(player, new ItemStack(ModItems.ENERGY_CHARGE.get()), 10f, 1.6f, 0f);
            case ALIEN -> {
                Vec3 end = eye.add(look.scale(8));
                var hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
                Vec3 dest = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation().subtract(look.scale(0.7));
                Vec3 from = player.position();
                player.teleportTo(dest.x, dest.y - player.getEyeHeight() + 0.1, dest.z);
                player.resetFallDistance();
                player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 60, 0, false, false, true));
                Attacks.line(server, from.add(0, 1, 0), player.position().add(0, 1, 0), power.color);
                sound(server, player, SoundEvents.ENDERMAN_TELEPORT, 1.4f);
            }
            case SPEED -> {
                Vec3 from = player.position();
                player.setDeltaMovement(look.x * 2.4, Math.max(0.2, look.y * 1.2), look.z * 2.4);
                player.hurtMarked = true;
                player.resetFallDistance();
                Attacks.line(server, from.add(0, 1, 0), from.add(look.scale(6)).add(0, 1, 0), power.color);
                sound(server, player, SoundEvents.TRIDENT_RIPTIDE_1.value(), 1.4f);
            }
            case TITAN -> Attacks.slam(player, 6, 14f, 0.9, power.color);
            case GUARDIAN -> {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 120, 2));
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 120, 2));
                for (int i = 0; i < 4; i++) {
                    Attacks.ring(server, player.position().add(0, 0.3 + i * 0.5, 0), 1.2, power.color, 30);
                }
                sound(server, player, SoundEvents.BEACON_ACTIVATE, 1.5f);
            }
            case KING -> {
                Attacks.affectNearby(player, 8, new MobEffectInstance(MobEffects.LEVITATION, 60, 1));
                Attacks.affectNearby(player, 8, new MobEffectInstance(MobEffects.GLOWING, 100, 0));
                Attacks.ring(server, player.position().add(0, 0.2, 0), 8, power.color, 80);
                sound(server, player, SoundEvents.ENDERMAN_STARE, 1.2f);
            }
            case QUANTUM -> {
                ItemStack orb = new ItemStack(ModItems.QUANTUM_HEART.get());
                Vec3 side = new Vec3(-look.z, 0, look.x).normalize();
                for (int i = -2; i <= 2; i++) {
                    Vec3 aim = eye.add(look.scale(20)).add(side.scale(i * 2.5));
                    Attacks.shoot(player, aim, orb, 14f, 1.6f, 0f);
                }
                sound(server, player, SoundEvents.WARDEN_SONIC_BOOM, 1.2f);
            }
        }
        player.getCooldowns().addCooldown(this, power.cooldown);
        return InteractionResultHolder.success(stack);
    }

    private static void sound(ServerLevel server, Player player, SoundEvent sound, float pitch) {
        server.playSound(null, player.getX(), player.getY(), player.getZ(), sound, SoundSource.PLAYERS, 1f, pitch);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (selected && !level.isClientSide && entity instanceof LivingEntity living && living.tickCount % 20 == 0) {
            if (power == Power.SPEED) {
                living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 1, true, false, true));
            }
            if (level instanceof ServerLevel server) {
                Attacks.burst(server, new Vec3(living.getX(), living.getY(0.5), living.getZ()), power.color, 2, 0.5);
            }
        }
        super.inventoryTick(stack, level, entity, slot, selected);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return power == Power.KING || power == Power.QUANTUM || power == Power.GUARDIAN || super.isFoil(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal(power.onHit).withStyle(ChatFormatting.AQUA));
        tip.add(Component.literal(power.onUse).withStyle(ChatFormatting.GOLD));
    }
}
