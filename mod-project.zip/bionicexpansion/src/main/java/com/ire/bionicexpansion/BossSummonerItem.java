package com.ire.bionicexpansion;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.function.Supplier;

/** Right-click to summon a boss a few blocks in front of you. Used up on success. */
public class BossSummonerItem extends Item {
    private final Supplier<? extends EntityType<? extends Mob>> boss;
    private final String bossName;

    public BossSummonerItem(Supplier<? extends EntityType<? extends Mob>> boss, String bossName, Properties props) {
        super(props);
        this.boss = boss;
        this.bossName = bossName;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            BlockPos pos = player.blockPosition().relative(player.getDirection(), 5);
            Mob mob = boss.get().spawn(server, pos, MobSpawnType.MOB_SUMMONED);
            if (mob == null) {
                player.displayClientMessage(Component.literal("Not enough room to summon " + bossName)
                        .withStyle(ChatFormatting.RED), true);
                return InteractionResultHolder.fail(stack);
            }
            mob.setTarget(player);
            mob.setPersistenceRequired();
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
            server.playSound(null, pos, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1.5f, 1f);
            player.sendSystemMessage(Component.literal(bossName + " has been summoned!")
                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("Right-click to summon " + bossName).withStyle(ChatFormatting.RED));
        tip.add(Component.literal("Get ready first!").withStyle(ChatFormatting.GRAY));
    }
}
