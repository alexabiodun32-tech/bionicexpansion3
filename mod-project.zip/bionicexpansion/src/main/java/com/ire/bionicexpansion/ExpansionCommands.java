package com.ire.bionicexpansion;

import com.ire.bionicexpansion.entity.ModEntities;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Adds to Mod 1's /bionic command (Brigadier merges the two):
 * /bionic give pickaxes|upgrades|swords|vehicles|summoners|ultimate_power_core
 * /bionic summon guardian|alien_king|speed_demon|titan|quantum_entity
 */
@EventBusSubscriber(modid = BionicExpansion.MODID)
public class ExpansionCommands {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("bionic")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("give")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.literal("pickaxes").executes(c -> give(c.getSource(),
                                ModItems.SPEED_PICKAXE.get(), ModItems.BIONIC_PICKAXE.get(), ModItems.MAGMA_PICKAXE.get(),
                                ModItems.QUANTUM_PICKAXE.get(), ModItems.VOID_PICKAXE.get(), ModItems.ULTIMATE_PICKAXE.get())))
                        .then(Commands.literal("upgrades").executes(c -> give(c.getSource(),
                                ModItems.VEIN_MODULE.get(), ModItems.AREA_MODULE.get(), ModItems.SMELT_MODULE.get(),
                                ModItems.MAGNET_MODULE.get(), ModItems.DURABILITY_MODULE.get(), ModItems.POWER_MODULE.get())))
                        .then(Commands.literal("swords").executes(c -> give(c.getSource(),
                                ModItems.MUTANT_CLEAVER.get(), ModItems.PLASMA_SWORD.get(), ModItems.ALIEN_SABER.get(),
                                ModItems.SPEED_BLADE.get(), ModItems.TITAN_HAMMER.get(), ModItems.GUARDIAN_BLADE.get(),
                                ModItems.KING_SCEPTER.get(), ModItems.QUANTUM_BLADE.get())))
                        .then(Commands.literal("vehicles").executes(c -> give(c.getSource(),
                                ModItems.HOVERBIKE.get(), ModItems.JET.get())))
                        .then(Commands.literal("summoners").executes(c -> give(c.getSource(),
                                ModItems.GUARDIAN_SUMMONER.get(), ModItems.ALIEN_KING_SUMMONER.get(),
                                ModItems.SPEED_DEMON_SUMMONER.get(), ModItems.TITAN_SUMMONER.get(),
                                ModItems.QUANTUM_SUMMONER.get())))
                        .then(Commands.literal("ultimate_power_core").executes(c -> give(c.getSource(),
                                ModItems.ULTIMATE_POWER_CORE.get()))))
                .then(Commands.literal("summon")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.literal("guardian").executes(c -> summon(c.getSource(), ModEntities.BIONIC_GUARDIAN.get())))
                        .then(Commands.literal("alien_king").executes(c -> summon(c.getSource(), ModEntities.ALIEN_KING.get())))
                        .then(Commands.literal("speed_demon").executes(c -> summon(c.getSource(), ModEntities.SPEED_DEMON_BOSS.get())))
                        .then(Commands.literal("titan").executes(c -> summon(c.getSource(), ModEntities.TITAN_BOSS.get())))
                        .then(Commands.literal("quantum_entity").executes(c -> summon(c.getSource(), ModEntities.QUANTUM_ENTITY.get())))));
    }

    private static int give(CommandSourceStack src, Item... items) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        for (Item item : items) {
            ItemStack stack = new ItemStack(item);
            if (!p.getInventory().add(stack)) {
                p.drop(stack, false);
            }
        }
        src.sendSuccess(() -> Component.literal("Bionic items given."), false);
        return 1;
    }

    private static int summon(CommandSourceStack src, EntityType<? extends Mob> type) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        BlockPos pos = p.blockPosition().relative(p.getDirection(), 5);
        Mob mob = type.spawn(p.serverLevel(), pos, MobSpawnType.COMMAND);
        if (mob == null) {
            src.sendFailure(Component.literal("Couldn't summon it here. Try somewhere with more room."));
            return 0;
        }
        mob.setTarget(p);
        mob.setPersistenceRequired();
        src.sendSuccess(() -> Component.literal("Summoned " + mob.getDisplayName().getString() + "!"), false);
        return 1;
    }
}
