package com.ire.bionicexpansion;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** Gives flight while an Ultimate Power Core is anywhere in the inventory. */
@EventBusSubscriber(modid = BionicExpansion.MODID)
public class ExpansionEvents {
    private static final String FLY_TAG = "bionicexpansion_flight";

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide || player.tickCount % 10 != 0) return;
        if (player.isCreative() || player.isSpectator()) return;

        boolean hasCore = false;
        for (ItemStack s : player.getInventory().items) {
            if (s.getItem() instanceof UltimatePowerCoreItem) {
                hasCore = true;
                break;
            }
        }
        if (player.getOffhandItem().getItem() instanceof UltimatePowerCoreItem) hasCore = true;

        if (hasCore) {
            if (!player.getAbilities().mayfly) {
                player.getAbilities().mayfly = true;
                player.getPersistentData().putBoolean(FLY_TAG, true);
                player.onUpdateAbilities();
            }
        } else if (player.getPersistentData().getBoolean(FLY_TAG)) {
            player.getPersistentData().remove(FLY_TAG);
            player.getAbilities().mayfly = false;
            player.getAbilities().flying = false;
            player.onUpdateAbilities();
        }
    }
}
