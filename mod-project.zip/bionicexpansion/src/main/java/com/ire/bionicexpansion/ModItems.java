package com.ire.bionicexpansion;

import com.ire.bionicexpansion.entity.ModEntities;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumSet;
import java.util.Set;
import java.util.function.Supplier;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(BionicExpansion.MODID);

    // ---------- Enemy and boss drops ----------
    public static final DeferredItem<Item> MUTANT_CORE = material("mutant_core", Rarity.UNCOMMON);
    public static final DeferredItem<Item> BIONIC_ALLOY = material("bionic_alloy", Rarity.UNCOMMON);
    public static final DeferredItem<Item> ALIEN_CORE = material("alien_core", Rarity.UNCOMMON);
    public static final DeferredItem<Item> TITAN_CORE = material("titan_core", Rarity.RARE);
    public static final DeferredItem<Item> GUARDIAN_CORE = material("guardian_core", Rarity.RARE);
    public static final DeferredItem<Item> ALIEN_KING_CORE = material("alien_king_core", Rarity.RARE);
    public static final DeferredItem<Item> SPEED_DEMON_CORE = material("speed_demon_core", Rarity.RARE);
    public static final DeferredItem<Item> QUANTUM_HEART = material("quantum_heart", Rarity.EPIC);
    /** Only used as the look of energy blasts; hidden from the creative tab. */
    public static final DeferredItem<Item> ENERGY_CHARGE = ITEMS.registerSimpleItem("energy_charge");
    public static final DeferredItem<Item> BIONIC_UPGRADE_TEMPLATE = material("bionic_upgrade_template", Rarity.UNCOMMON);

    public static final DeferredItem<UltimatePowerCoreItem> ULTIMATE_POWER_CORE = ITEMS.register("ultimate_power_core",
            () -> new UltimatePowerCoreItem(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC)));

    // ---------- Pickaxes ----------
    public static final DeferredItem<BionicPickaxeItem> SPEED_PICKAXE = pickaxe("speed_pickaxe",
            new BionicTier(1800, 22f, 3f, 15, () -> Ingredient.of(Items.DIAMOND)), 5f,
            EnumSet.noneOf(PickAbility.class), BionicPickaxeItem.HeldEffect.NONE, false, false);
    public static final DeferredItem<BionicPickaxeItem> BIONIC_PICKAXE = pickaxe("bionic_pickaxe",
            new BionicTier(6000, 14f, 4f, 15, () -> Ingredient.of(BIONIC_ALLOY.get())), 6f,
            EnumSet.of(PickAbility.DURABILITY), BionicPickaxeItem.HeldEffect.NONE, false, false);
    public static final DeferredItem<BionicPickaxeItem> MAGMA_PICKAXE = pickaxe("magma_pickaxe",
            new BionicTier(4500, 16f, 5f, 15, () -> Ingredient.of(BIONIC_ALLOY.get())), 7f,
            EnumSet.of(PickAbility.SMELT), BionicPickaxeItem.HeldEffect.FIRE, false, false);
    public static final DeferredItem<BionicPickaxeItem> QUANTUM_PICKAXE = pickaxe("quantum_pickaxe",
            new BionicTier(5500, 35f, 5f, 18, () -> Ingredient.of(BIONIC_ALLOY.get())), 7f,
            EnumSet.of(PickAbility.VEIN), BionicPickaxeItem.HeldEffect.NONE, true, false);
    public static final DeferredItem<BionicPickaxeItem> VOID_PICKAXE = pickaxe("void_pickaxe",
            new BionicTier(7500, 50f, 6f, 20, () -> Ingredient.of(BIONIC_ALLOY.get())), 8f,
            EnumSet.of(PickAbility.AREA, PickAbility.MAGNET), BionicPickaxeItem.HeldEffect.VOID, true, false);
    public static final DeferredItem<BionicPickaxeItem> ULTIMATE_PICKAXE = pickaxe("ultimate_pickaxe",
            new BionicTier(9999, 80f, 10f, 25, () -> Ingredient.of(QUANTUM_HEART.get())), 10f,
            EnumSet.allOf(PickAbility.class), BionicPickaxeItem.HeldEffect.ULTIMATE, true, true);

    // ---------- Pickaxe upgrade modules ----------
    public static final DeferredItem<UpgradeModuleItem> VEIN_MODULE = module("vein_module", PickAbility.VEIN);
    public static final DeferredItem<UpgradeModuleItem> AREA_MODULE = module("area_module", PickAbility.AREA);
    public static final DeferredItem<UpgradeModuleItem> SMELT_MODULE = module("smelt_module", PickAbility.SMELT);
    public static final DeferredItem<UpgradeModuleItem> MAGNET_MODULE = module("magnet_module", PickAbility.MAGNET);
    public static final DeferredItem<UpgradeModuleItem> DURABILITY_MODULE = module("durability_module", PickAbility.DURABILITY);
    public static final DeferredItem<UpgradeModuleItem> POWER_MODULE = module("power_module", PickAbility.POWER);

    // ---------- Swords ----------
    public static final DeferredItem<BionicSwordItem> MUTANT_CLEAVER = sword("mutant_cleaver", BionicSwordItem.Power.MUTANT,
            2500, 9, -2.6f, () -> Ingredient.of(MUTANT_CORE.get()), Rarity.UNCOMMON, false);
    public static final DeferredItem<BionicSwordItem> PLASMA_SWORD = sword("plasma_sword", BionicSwordItem.Power.PLASMA,
            2500, 8, -2.4f, () -> Ingredient.of(BIONIC_ALLOY.get()), Rarity.UNCOMMON, false);
    public static final DeferredItem<BionicSwordItem> ALIEN_SABER = sword("alien_saber", BionicSwordItem.Power.ALIEN,
            2500, 9, -2.4f, () -> Ingredient.of(ALIEN_CORE.get()), Rarity.UNCOMMON, false);
    public static final DeferredItem<BionicSwordItem> SPEED_BLADE = sword("speed_blade", BionicSwordItem.Power.SPEED,
            2500, 7, -1.0f, () -> Ingredient.of(Items.DIAMOND), Rarity.UNCOMMON, false);
    public static final DeferredItem<BionicSwordItem> TITAN_HAMMER = sword("titan_hammer", BionicSwordItem.Power.TITAN,
            4000, 15, -3.2f, () -> Ingredient.of(TITAN_CORE.get()), Rarity.RARE, false);
    public static final DeferredItem<BionicSwordItem> GUARDIAN_BLADE = sword("guardian_blade", BionicSwordItem.Power.GUARDIAN,
            4000, 12, -2.4f, () -> Ingredient.of(BIONIC_ALLOY.get()), Rarity.RARE, false);
    public static final DeferredItem<BionicSwordItem> KING_SCEPTER = sword("king_scepter", BionicSwordItem.Power.KING,
            4000, 12, -2.6f, () -> Ingredient.of(ALIEN_CORE.get()), Rarity.RARE, false);
    public static final DeferredItem<BionicSwordItem> QUANTUM_BLADE = sword("quantum_blade", BionicSwordItem.Power.QUANTUM,
            9999, 19, -2.2f, () -> Ingredient.of(QUANTUM_HEART.get()), Rarity.EPIC, true);

    // ---------- Vehicles ----------
    public static final DeferredItem<VehicleItem> HOVERBIKE = ITEMS.register("hoverbike",
            () -> new VehicleItem(ModEntities.HOVERBIKE, "Fast hover bike: glides over water and lava",
                    new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final DeferredItem<VehicleItem> JET = ITEMS.register("jet",
            () -> new VehicleItem(ModEntities.JET, "Hold W to fly where you look; let go to hover",
                    new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    // ---------- Boss summoners ----------
    public static final DeferredItem<BossSummonerItem> GUARDIAN_SUMMONER = ITEMS.register("guardian_summoner",
            () -> new BossSummonerItem(ModEntities.BIONIC_GUARDIAN, "The Bionic Guardian", new Item.Properties().rarity(Rarity.RARE)));
    public static final DeferredItem<BossSummonerItem> ALIEN_KING_SUMMONER = ITEMS.register("alien_king_summoner",
            () -> new BossSummonerItem(ModEntities.ALIEN_KING, "The Alien King", new Item.Properties().rarity(Rarity.RARE)));
    public static final DeferredItem<BossSummonerItem> SPEED_DEMON_SUMMONER = ITEMS.register("speed_demon_summoner",
            () -> new BossSummonerItem(ModEntities.SPEED_DEMON_BOSS, "The Speed Demon", new Item.Properties().rarity(Rarity.RARE)));
    public static final DeferredItem<BossSummonerItem> TITAN_SUMMONER = ITEMS.register("titan_summoner",
            () -> new BossSummonerItem(ModEntities.TITAN_BOSS, "The Titan", new Item.Properties().rarity(Rarity.RARE)));
    public static final DeferredItem<BossSummonerItem> QUANTUM_SUMMONER = ITEMS.register("quantum_summoner",
            () -> new BossSummonerItem(ModEntities.QUANTUM_ENTITY, "The Quantum Entity", new Item.Properties().rarity(Rarity.EPIC)));

    // ---------- Spawn eggs ----------
    static {
        egg("mutant_zombie", ModEntities.MUTANT_ZOMBIE, 0x3E5A2A, 0x9BE05A);
        egg("bionic_soldier", ModEntities.BIONIC_SOLDIER, 0x5A6470, 0x3CE8FF);
        egg("alien", ModEntities.ALIEN, 0x6FBF8E, 0x1A1A1A);
        egg("speed_demon", ModEntities.SPEED_DEMON, 0x5A0E0E, 0xFFD23C);
        egg("titan", ModEntities.TITAN, 0x6B625A, 0xFF8A2A);
        egg("experiment", ModEntities.EXPERIMENT, 0xE8E8EC, 0xA24CE0);
        egg("bionic_guardian", ModEntities.BIONIC_GUARDIAN, 0x2B2F36, 0xFF2A2A);
        egg("alien_king", ModEntities.ALIEN_KING, 0x5B2A86, 0xFFC93C);
        egg("speed_demon_boss", ModEntities.SPEED_DEMON_BOSS, 0x1A0A0A, 0xFF3C1A);
        egg("titan_boss", ModEntities.TITAN_BOSS, 0x2A2626, 0xFF5A00);
        egg("quantum_entity", ModEntities.QUANTUM_ENTITY, 0x0A0A2E, 0xC43CFF);
    }

    // ---------- helpers ----------
    private static DeferredItem<Item> material(String name, Rarity rarity) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().rarity(rarity)));
    }

    private static DeferredItem<BionicPickaxeItem> pickaxe(String name, BionicTier tier, float damage,
                                                           Set<PickAbility> abilities, BionicPickaxeItem.HeldEffect held,
                                                           boolean foil, boolean unbreakable) {
        return ITEMS.register(name, () -> {
            Item.Properties props = new Item.Properties().fireResistant()
                    .rarity(unbreakable ? Rarity.EPIC : foil ? Rarity.RARE : Rarity.UNCOMMON);
            if (unbreakable) {
                props = props.component(DataComponents.UNBREAKABLE, new Unbreakable(true));
            }
            return new BionicPickaxeItem(tier, damage, props, abilities, held, foil);
        });
    }

    private static DeferredItem<UpgradeModuleItem> module(String name, PickAbility ability) {
        return ITEMS.register(name, () -> new UpgradeModuleItem(ability, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    }

    /** attackDamage is the sword's total damage minus 1 (the player's own punch). */
    private static DeferredItem<BionicSwordItem> sword(String name, BionicSwordItem.Power power, int uses, int attackDamage,
                                                       float attackSpeed, Supplier<Ingredient> repair, Rarity rarity,
                                                       boolean unbreakable) {
        return ITEMS.register(name, () -> {
            BionicTier tier = new BionicTier(uses, 9f, 0f, 15, repair);
            Item.Properties props = new Item.Properties().fireResistant().rarity(rarity);
            if (unbreakable) {
                props = props.component(DataComponents.UNBREAKABLE, new Unbreakable(true));
            }
            return new BionicSwordItem(tier, attackDamage, attackSpeed, power, props);
        });
    }

    private static void egg(String name, Supplier<? extends EntityType<? extends Mob>> type, int background, int highlight) {
        ITEMS.register(name + "_spawn_egg", () -> new DeferredSpawnEggItem(type, background, highlight, new Item.Properties()));
    }
}
