package com.ire.bionicexpansion;

/** Special abilities a Bionic pickaxe can have, either built in or added with an upgrade module. */
public enum PickAbility {
    VEIN("Vein Mine", "Crouch + mine an ore to break the whole vein"),
    AREA("3x3 Mining", "Mines a 3x3 area (stand up to use it)"),
    SMELT("Auto-Smelt", "Ores drop already smelted"),
    MAGNET("Magnet", "Mined items fly straight to you"),
    DURABILITY("Durability Boost", "Much harder to break"),
    POWER("Power Mode", "Right-click: insanely fast mining for 10 seconds");

    public final String title;
    public final String help;

    PickAbility(String title, String help) {
        this.title = title;
        this.help = help;
    }

    /** Key used to store this upgrade on the pickaxe. */
    public String key() {
        return "bionic_upgrade_" + name().toLowerCase();
    }
}
