package com.ire.bionicexpansion;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.BlockDropsEvent;
import net.neoforged.neoforge.event.level.BlockEvent;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/** Vein mining, 3x3 mining, auto-smelt, magnet and Power Mode for the Bionic pickaxes. */
@EventBusSubscriber(modid = BionicExpansion.MODID)
public class PickaxeEvents {
    private static final int MAX_VEIN = 64;
    private static boolean breakingExtra = false;

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (breakingExtra) return;
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;
        LevelAccessor accessor = event.getLevel();
        if (!(accessor instanceof ServerLevel level)) return;
        ItemStack tool = player.getMainHandItem();
        if (!(tool.getItem() instanceof BionicPickaxeItem pick)) return;

        BlockPos origin = event.getPos();
        BlockState state = event.getState();

        List<BlockPos> extra = new ArrayList<>();
        if (player.isShiftKeyDown() && BionicPickaxeItem.has(tool, PickAbility.VEIN) && state.is(Tags.Blocks.ORES)) {
            extra = vein(level, origin, state.getBlock());
        } else if (!player.isShiftKeyDown() && BionicPickaxeItem.has(tool, PickAbility.AREA)) {
            extra = area(player, origin);
        }

        if (pick.heldEffect() == BionicPickaxeItem.HeldEffect.VOID || pick.heldEffect() == BionicPickaxeItem.HeldEffect.ULTIMATE) {
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, origin.getX() + 0.5, origin.getY() + 0.5, origin.getZ() + 0.5,
                    12, 0.4, 0.4, 0.4, 0.05);
        }
        if (extra.isEmpty()) return;

        breakingExtra = true;
        try {
            for (BlockPos pos : extra) {
                if (player.getMainHandItem() != tool || tool.isEmpty()) break; // pickaxe broke or was swapped
                BlockState other = level.getBlockState(pos);
                if (other.isAir() || other.getDestroySpeed(level, pos) < 0) continue;
                if (!other.is(BlockTags.MINEABLE_WITH_PICKAXE) && !other.is(Tags.Blocks.ORES)) continue;
                player.gameMode.destroyBlock(pos);
            }
        } finally {
            breakingExtra = false;
        }
    }

    /** Blocks of the same type touching the origin (including diagonals), up to MAX_VEIN. */
    private static List<BlockPos> vein(ServerLevel level, BlockPos origin, Block block) {
        List<BlockPos> found = new ArrayList<>();
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        seen.add(origin);
        queue.add(origin);
        while (!queue.isEmpty() && found.size() < MAX_VEIN) {
            BlockPos current = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos next = current.offset(dx, dy, dz);
                        if (seen.add(next) && level.getBlockState(next).is(block)) {
                            found.add(next);
                            queue.add(next);
                            if (found.size() >= MAX_VEIN) return found;
                        }
                    }
                }
            }
        }
        return found;
    }

    /** The 8 blocks around the origin, on the face the player is looking at. */
    private static List<BlockPos> area(Player player, BlockPos origin) {
        List<BlockPos> out = new ArrayList<>();
        boolean lookingUpOrDown = Math.abs(player.getXRot()) > 50f;
        Direction.Axis facing = player.getDirection().getAxis();
        for (int a = -1; a <= 1; a++) {
            for (int b = -1; b <= 1; b++) {
                if (a == 0 && b == 0) continue;
                BlockPos pos;
                if (lookingUpOrDown) {
                    pos = origin.offset(a, 0, b);
                } else if (facing == Direction.Axis.X) {
                    pos = origin.offset(0, a, b);
                } else {
                    pos = origin.offset(a, b, 0);
                }
                out.add(pos);
            }
        }
        return out;
    }

    @SubscribeEvent
    public static void onDrops(BlockDropsEvent event) {
        Entity breaker = event.getBreaker();
        if (!(breaker instanceof Player player)) return;
        ItemStack tool = event.getTool();
        if (!(tool.getItem() instanceof BionicPickaxeItem)) return;
        LevelAccessor accessor = event.getLevel();
        if (!(accessor instanceof ServerLevel level)) return;

        if (BionicPickaxeItem.has(tool, PickAbility.SMELT) && event.getState().is(Tags.Blocks.ORES)) {
            for (ItemEntity drop : event.getDrops()) {
                ItemStack stack = drop.getItem();
                Optional<RecipeHolder<SmeltingRecipe>> recipe = level.getRecipeManager()
                        .getRecipeFor(RecipeType.SMELTING, new SingleRecipeInput(stack), level);
                if (recipe.isPresent()) {
                    ItemStack result = recipe.get().value().getResultItem(level.registryAccess());
                    if (!result.isEmpty()) {
                        drop.setItem(result.copyWithCount(Math.min(result.getMaxStackSize(), result.getCount() * stack.getCount())));
                    }
                }
            }
            BlockPos pos = event.getPos();
            level.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 6, 0.3, 0.3, 0.3, 0.01);
        }

        if (BionicPickaxeItem.has(tool, PickAbility.MAGNET)) {
            for (ItemEntity drop : event.getDrops()) {
                drop.setPos(player.getX(), player.getY() + 0.5, player.getZ());
                drop.setNoPickUpDelay();
            }
        }
    }

    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed event) {
        Player player = event.getEntity();
        ItemStack tool = player.getMainHandItem();
        if (tool.getItem() instanceof BionicPickaxeItem && BionicPickaxeItem.isPowered(tool, player.level())) {
            event.setNewSpeed(event.getNewSpeed() * 6f);
        }
    }
}
