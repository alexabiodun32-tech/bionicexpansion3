package com.ire.bionicexpansion;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Endgame core made from Mod 1's Bionic Super Core and the Quantum Heart.
 * Works from anywhere in your inventory. Flight is handled in ExpansionEvents.
 */
public class UltimatePowerCoreItem extends Item {
    public UltimatePowerCoreItem(Properties props) {
        super(props);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (!level.isClientSide && entity instanceof Player player && player.tickCount % 10 == 0) {
            effect(player, MobEffects.MOVEMENT_SPEED, 4);
            effect(player, MobEffects.DAMAGE_BOOST, 9);
            effect(player, MobEffects.DAMAGE_RESISTANCE, 4);
            effect(player, MobEffects.DIG_SPEED, 3);
            effect(player, MobEffects.REGENERATION, 3);
            effect(player, MobEffects.JUMP, 3);
            effect(player, MobEffects.FIRE_RESISTANCE, 0);
            effect(player, MobEffects.WATER_BREATHING, 0);
            effect(player, MobEffects.SATURATION, 0);
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, true, false, true));
        }
        super.inventoryTick(stack, level, entity, slot, selected);
    }

    private static void effect(Player player, Holder<MobEffect> effect, int amplifier) {
        player.addEffect(new MobEffectInstance(effect, 40, amplifier, true, false, true));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("Powered by the Quantum Heart.").withStyle(ChatFormatting.LIGHT_PURPLE));
        tip.add(Component.literal("Works from anywhere in your inventory").withStyle(ChatFormatting.GRAY));
        tip.add(Component.literal("Flight, Speed V, Strength X, Resistance V, Haste IV,").withStyle(ChatFormatting.AQUA));
        tip.add(Component.literal("Regen IV, Jump IV, fire and water immunity, night vision").withStyle(ChatFormatting.AQUA));
    }
}
