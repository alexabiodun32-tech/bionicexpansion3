package com.ire.bionicexpansion;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Hold this in one hand and a Bionic pickaxe in the other, then right-click to install it. */
public class UpgradeModuleItem extends Item {
    private final PickAbility ability;

    public UpgradeModuleItem(PickAbility ability, Properties props) {
        super(props);
        this.ability = ability;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack module = player.getItemInHand(hand);
        InteractionHand other = hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
        ItemStack pick = player.getItemInHand(other);

        if (!(pick.getItem() instanceof BionicPickaxeItem)) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.literal("Hold a Bionic pickaxe in your other hand first")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResultHolder.fail(module);
        }
        if (BionicPickaxeItem.has(pick, ability)) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.literal("That pickaxe already has " + ability.title)
                        .withStyle(ChatFormatting.YELLOW), true);
            }
            return InteractionResultHolder.fail(module);
        }

        if (!level.isClientSide) {
            BionicPickaxeItem.addUpgrade(pick, ability);
            if (ability == PickAbility.DURABILITY && !pick.has(DataComponents.UNBREAKABLE)) {
                pick.set(DataComponents.MAX_DAMAGE, pick.getMaxDamage() * 3);
            }
            if (!player.getAbilities().instabuild) {
                module.shrink(1);
            }
            player.displayClientMessage(Component.literal("Installed " + ability.title + "!")
                    .withStyle(ChatFormatting.GREEN), true);
            level.playSound(null, player.blockPosition(), SoundEvents.SMITHING_TABLE_USE, SoundSource.PLAYERS, 1f, 1.2f);
        }
        return InteractionResultHolder.sidedSuccess(module, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal(ability.help).withStyle(ChatFormatting.AQUA));
        tip.add(Component.literal("Hold a Bionic pickaxe in your other hand and right-click")
                .withStyle(ChatFormatting.GRAY));
    }
}
