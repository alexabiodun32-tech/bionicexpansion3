package com.ire.bionicexpansion;

import com.ire.bionicexpansion.entity.VehicleEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;

import java.util.List;
import java.util.function.Supplier;

/** Right-click the ground to place the vehicle. */
public class VehicleItem extends Item {
    private final Supplier<? extends EntityType<? extends VehicleEntity>> vehicle;
    private final String help;

    public VehicleItem(Supplier<? extends EntityType<? extends VehicleEntity>> vehicle, String help, Properties props) {
        super(props);
        this.vehicle = vehicle;
        this.help = help;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (!(ctx.getLevel() instanceof ServerLevel server)) {
            return InteractionResult.SUCCESS;
        }
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        VehicleEntity v = vehicle.get().spawn(server, pos, MobSpawnType.SPAWN_EGG);
        if (v == null) {
            return InteractionResult.FAIL;
        }
        Player player = ctx.getPlayer();
        if (player != null) {
            v.setYRot(player.getYRot());
            v.yBodyRot = player.getYRot();
            v.yHeadRot = player.getYRot();
            if (!player.getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("Right-click the ground to place it").withStyle(ChatFormatting.GRAY));
        tip.add(Component.literal(help).withStyle(ChatFormatting.AQUA));
        tip.add(Component.literal("Right-click it to get in, crouch to get out").withStyle(ChatFormatting.GRAY));
    }
}
