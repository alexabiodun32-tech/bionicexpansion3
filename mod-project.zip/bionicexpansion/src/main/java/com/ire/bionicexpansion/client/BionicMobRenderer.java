package com.ire.bionicexpansion.client;

import com.ire.bionicexpansion.BionicExpansion;
import com.ire.bionicexpansion.entity.BionicMob;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/**
 * Draws a Bionic mob with its animated GeckoLib model. Files used (for name "titan"):
 * geo/entity/titan.geo.json, animations/entity/titan.animation.json,
 * textures/entity/titan.png and textures/entity/titan_glowmask.png (the parts that glow in the dark).
 */
public class BionicMobRenderer<T extends BionicMob> extends GeoEntityRenderer<T> {
    public BionicMobRenderer(EntityRendererProvider.Context ctx, String name, float shadow) {
        super(ctx, new DefaultedEntityGeoModel<>(ResourceLocation.fromNamespaceAndPath(BionicExpansion.MODID, name), true));
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
        this.shadowRadius = shadow;
    }
}
