package com.ire.bionicexpansion.client;

import com.ire.bionicexpansion.BionicExpansion;
import com.ire.bionicexpansion.entity.ModEntities;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = BionicExpansion.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.MUTANT_ZOMBIE.get(), ctx -> new BionicMobRenderer<>(ctx, "mutant_zombie", 0.6f));
        event.registerEntityRenderer(ModEntities.BIONIC_SOLDIER.get(), ctx -> new BionicMobRenderer<>(ctx, "bionic_soldier", 0.5f));
        event.registerEntityRenderer(ModEntities.ALIEN.get(), ctx -> new BionicMobRenderer<>(ctx, "alien", 0.5f));
        event.registerEntityRenderer(ModEntities.SPEED_DEMON.get(), ctx -> new BionicMobRenderer<>(ctx, "speed_demon", 0.5f));
        event.registerEntityRenderer(ModEntities.TITAN.get(), ctx -> new BionicMobRenderer<>(ctx, "titan", 1.0f));
        event.registerEntityRenderer(ModEntities.EXPERIMENT.get(), ctx -> new BionicMobRenderer<>(ctx, "experiment", 0.5f));
        event.registerEntityRenderer(ModEntities.BIONIC_GUARDIAN.get(), ctx -> new BionicMobRenderer<>(ctx, "bionic_guardian", 1.4f));
        event.registerEntityRenderer(ModEntities.ALIEN_KING.get(), ctx -> new BionicMobRenderer<>(ctx, "alien_king", 0.9f));
        event.registerEntityRenderer(ModEntities.SPEED_DEMON_BOSS.get(), ctx -> new BionicMobRenderer<>(ctx, "speed_demon_boss", 0.9f));
        event.registerEntityRenderer(ModEntities.TITAN_BOSS.get(), ctx -> new BionicMobRenderer<>(ctx, "titan_boss", 2.0f));
        event.registerEntityRenderer(ModEntities.QUANTUM_ENTITY.get(), ctx -> new BionicMobRenderer<>(ctx, "quantum_entity", 1.0f));
        event.registerEntityRenderer(ModEntities.QUANTUM_CLONE.get(), ctx -> new BionicMobRenderer<>(ctx, "quantum_clone", 0.6f));
        event.registerEntityRenderer(ModEntities.HOVERBIKE.get(), ctx -> new VehicleRenderer<>(ctx, "hoverbike", 0.8f));
        event.registerEntityRenderer(ModEntities.JET.get(), ctx -> new VehicleRenderer<>(ctx, "jet", 1.2f));
        event.registerEntityRenderer(ModEntities.ENERGY_BLAST.get(), ctx -> new ThrownItemRenderer<>(ctx, 1.5f, true));
    }
}
