package com.ire.bionicexpansion.client;

import com.ire.bionicexpansion.BionicExpansion;
import com.ire.bionicexpansion.entity.Jet;
import com.ire.bionicexpansion.entity.VehicleEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** Draws a vehicle. The jet also tilts its nose up and down with the pilot's view. */
public class VehicleRenderer<T extends VehicleEntity> extends GeoEntityRenderer<T> {
    public VehicleRenderer(EntityRendererProvider.Context ctx, String name, float shadow) {
        super(ctx, new VehicleModel<>(ResourceLocation.fromNamespaceAndPath(BionicExpansion.MODID, name)));
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
        this.shadowRadius = shadow;
    }

    public static class VehicleModel<T extends VehicleEntity> extends DefaultedEntityGeoModel<T> {
        public VehicleModel(ResourceLocation path) {
            super(path, false);
        }

        @Override
        public void setCustomAnimations(T animatable, long instanceId, AnimationState<T> animationState) {
            super.setCustomAnimations(animatable, instanceId, animationState);
            GeoBone root = getAnimationProcessor().getBone("root");
            if (root != null) {
                float pitch = animatable instanceof Jet && animatable.isVehicle() ? animatable.getXRot() : 0f;
                root.setRotX(pitch * Mth.DEG_TO_RAD);
            }
        }
    }
}
