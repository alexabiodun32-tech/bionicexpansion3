package com.ire.bionicexpansion.entity;

import com.ire.bionicexpansion.ModItems;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Teleports short distances, shoots energy blasts and turns invisible. Drops Alien Core. */
public class Alien extends BionicMob {
    public Alien(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 12;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 28.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 5.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        LivingEntity target = targetWithin(24);
        if (target == null) return;
        int t = tickCount + getId(); // so a group of aliens don't all act on the same tick
        if (t % 50 == 0 && hasLineOfSight(target)) {
            shootAt(target, new ItemStack(ModItems.ALIEN_CORE.get()), 5f, 1.1f, 0f);
        }
        if (t % 90 == 0) {
            teleportNear(target.position(), 6);
        }
        if (t % 220 == 0) {
            addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 80, 0, false, false));
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENDERMAN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENDERMAN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDERMAN_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 1.5f;
    }

    @Override
    public int themeColor() {
        return 0x3CFFB0;
    }
}
