package com.ire.bionicexpansion.entity;

import com.ire.bionicexpansion.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * BOSS 2 - The Alien King. Floats above you, teleports, fires energy beams, summons Aliens and
 * opens portals under your feet that fling you into the sky. Drops the Alien King Core.
 */
public class AlienKing extends BionicBoss {
    private Vec3 portal = null;
    private int portalTicks = 0;

    public AlienKing(EntityType<? extends Monster> type, Level level) {
        super(type, level, BossEvent.BossBarColor.GREEN);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 350.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 12.0)
                .add(Attributes.ARMOR, 8.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    protected float[] phaseThresholds() {
        return new float[]{0.5f};
    }

    @Override
    protected void bossTick(LivingEntity target) {
        tickPortal();
        if (target == null) return;
        boolean angry = phase() >= 2;

        // Flying: hover a few blocks above the target.
        if (getY() < target.getY() + 3.5) {
            Vec3 m = getDeltaMovement();
            setDeltaMovement(m.x, Math.max(m.y, 0.22), m.z);
        }

        if (every(angry ? 20 : 35) && hasLineOfSight(target)) {
            ItemStack orb = new ItemStack(ModItems.ALIEN_CORE.get());
            shootAt(target, orb, 7f, 1.4f, 0f);
            if (angry) {
                Vec3 side = new Vec3(-(target.getZ() - getZ()), 0, target.getX() - getX()).normalize().scale(2.5);
                shootTowards(target.position().add(side).add(0, 1, 0), orb, 7f, 1.4f, 0f);
                shootTowards(target.position().subtract(side).add(0, 1, 0), orb, 7f, 1.4f, 0f);
            }
        }
        if (every(angry ? 70 : 110)) {
            teleportNear(target.position(), 10);
        }
        if (every(angry ? 120 : 170) && portal == null) {
            portal = target.position();
            portalTicks = 30;
            playSound(SoundEvents.PORTAL_TRIGGER, 1f, 1.5f);
        }
        if (every(angry ? 300 : 400)) {
            summon(ModEntities.ALIEN.get(), 2, 6);
        }
    }

    /** A portal opens under the target and, 1.5 seconds later, throws anyone standing on it upwards. */
    private void tickPortal() {
        if (portal == null || !(level() instanceof ServerLevel server)) return;
        server.sendParticles(ParticleTypes.REVERSE_PORTAL, portal.x, portal.y + 0.1, portal.z, 20, 1.2, 0.05, 1.2, 0.02);
        if (--portalTicks > 0) return;
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class,
                new net.minecraft.world.phys.AABB(portal.x - 1.5, portal.y - 1, portal.z - 1.5, portal.x + 1.5, portal.y + 2, portal.z + 1.5),
                x -> !(x instanceof BionicMob))) {
            e.teleportTo(e.getX() + random.nextInt(9) - 4, e.getY() + 12, e.getZ() + random.nextInt(9) - 4);
            e.hurtMarked = true;
        }
        server.sendParticles(ParticleTypes.PORTAL, portal.x, portal.y + 1, portal.z, 80, 1, 1, 1, 0.5);
        playSound(SoundEvents.ENDERMAN_TELEPORT, 2f, 0.6f);
        portal = null;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENDERMAN_STARE;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENDERMAN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDERMAN_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 0.7f;
    }

    @Override
    public int themeColor() {
        return 0xB43CFF;
    }
}
