package com.ire.bionicexpansion.entity;

import com.ire.bionicexpansion.Attacks;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

/**
 * Base class for the five bosses: boss health bar, phases, never despawns, no fall damage.
 * Summoned bosses never despawn (see BossSummonerItem); wild ones can.
 * Subclasses put their attacks in bossTick, which runs every server tick.
 */
public abstract class BionicBoss extends BionicMob {
    private final ServerBossEvent bossEvent;
    private int phase = 1;

    protected BionicBoss(EntityType<? extends Monster> type, Level level, BossEvent.BossBarColor color) {
        super(type, level);
        this.bossEvent = new ServerBossEvent(getDisplayName(), color, BossEvent.BossBarOverlay.NOTCHED_10);
        this.xpReward = 250;
    }

    /** Health fractions where the next phase starts, e.g. {0.5f} for a two-phase boss. */
    protected abstract float[] phaseThresholds();

    /** Runs every server tick while the boss is alive. */
    protected abstract void bossTick(LivingEntity target);

    /** Called once when a new phase starts. */
    protected void onPhaseChange(int newPhase) {
        announce(getDisplayName().getString() + " enters phase " + newPhase + "!");
        playSound(SoundEvents.WITHER_SPAWN, 2f, 1.2f);
        playSpecial();
        if (level() instanceof ServerLevel server) {
            for (int i = 1; i <= 4; i++) {
                Attacks.ring(server, position().add(0, 0.2 + i * 0.6, 0), 1.5 + i, themeColor(), 40);
            }
            server.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION_EMITTER, getX(), getY(1.0), getZ(), 1, 0, 0, 0, 0);
        }
    }

    public int phase() {
        return phase;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        float fraction = getHealth() / getMaxHealth();
        bossEvent.setProgress(fraction);

        int newPhase = 1;
        for (float threshold : phaseThresholds()) {
            if (fraction <= threshold) newPhase++;
        }
        if (newPhase > phase) {
            phase = newPhase;
            onPhaseChange(phase);
        }

        // boss aura: a slow spinning ring of its colour
        if (tickCount % 3 == 0 && level() instanceof ServerLevel server) {
            double a = tickCount * 0.25;
            double r = getBbWidth() * 0.9 + 0.6;
            server.sendParticles(Attacks.dust(themeColor(), 1.6f), getX() + Math.cos(a) * r, getY(0.3), getZ() + Math.sin(a) * r, 1, 0, 0, 0, 0);
            server.sendParticles(Attacks.dust(themeColor(), 1.6f), getX() - Math.cos(a) * r, getY(0.7), getZ() - Math.sin(a) * r, 1, 0, 0, 0, 0);
        }

        LivingEntity target = getTarget();
        if (target != null && !target.isAlive()) target = null;
        bossTick(target);
    }

    /** True once every `ticks` ticks (shorter in later phases if the caller passes a smaller number). */
    protected boolean every(int ticks) {
        return ticks > 0 && tickCount % ticks == 0;
    }

    /** Sends a chat message to players within 64 blocks. */
    protected void announce(String text) {
        if (!(level() instanceof ServerLevel server)) return;
        Component msg = Component.literal(text).withStyle(ChatFormatting.RED, ChatFormatting.BOLD);
        for (ServerPlayer p : server.players()) {
            if (p.distanceTo(this) < 64) p.sendSystemMessage(msg);
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        bossEvent.setName(getDisplayName());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        phase = Math.max(1, tag.getInt("BionicPhase"));
        if (hasCustomName()) bossEvent.setName(getDisplayName());
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("BionicPhase", phase);
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }
}
