package com.ire.bionicexpansion.entity;

import com.ire.bionicexpansion.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * BOSS 1 - The Bionic Guardian. Energy blasts, a shield, ground slams, summons Bionic Soldiers,
 * and gets faster and angrier in phase 2 (below half health). Drops the Guardian Core.
 */
public class BionicGuardian extends BionicBoss {
    private int shieldTicks = 0;

    public BionicGuardian(EntityType<? extends Monster> type, Level level) {
        super(type, level, BossEvent.BossBarColor.RED);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 14.0)
                .add(Attributes.ATTACK_KNOCKBACK, 1.5)
                .add(Attributes.ARMOR, 12.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.STEP_HEIGHT, 1.1);
    }

    @Override
    protected float[] phaseThresholds() {
        return new float[]{0.5f};
    }

    @Override
    protected void onPhaseChange(int newPhase) {
        super.onPhaseChange(newPhase);
        announce("The Bionic Guardian overloads its reactor!");
        summon(ModEntities.BIONIC_SOLDIER.get(), 3, 6);
    }

    @Override
    protected void bossTick(LivingEntity target) {
        if (shieldTicks > 0) {
            shieldTicks--;
            if (level() instanceof ServerLevel server && tickCount % 4 == 0) {
                server.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(0.5), getZ(), 12,
                        getBbWidth() * 0.6, getBbHeight() * 0.4, getBbWidth() * 0.6, 0.05);
            }
        }
        boolean angry = phase() >= 2;
        if (angry && tickCount % 40 == 0) {
            addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1, false, false));
        }
        if (target == null) return;

        if (every(angry ? 25 : 45) && hasLineOfSight(target)) {
            shootAt(target, new ItemStack(ModItems.ENERGY_CHARGE.get()), angry ? 10f : 8f, 1.3f, 0f);
        }
        if (every(angry ? 220 : 320) && shieldTicks == 0) {
            shieldTicks = 100;
            playSound(SoundEvents.BEACON_ACTIVATE, 2f, 1.4f);
        }
        if (every(angry ? 80 : 120) && distanceTo(target) < 8 && onGround()) {
            groundSlam(8, angry ? 14f : 10f, 0.8);
        }
        if (every(angry ? 300 : 400)) {
            summon(ModEntities.BIONIC_SOLDIER.get(), 2, 5);
        }
    }

    /** While the shield is up, all damage is blocked. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (shieldTicks > 0 && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            playSound(SoundEvents.SHIELD_BLOCK, 1.5f, 0.8f);
            return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.IRON_GOLEM_STEP;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.IRON_GOLEM_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 0.5f;
    }

    @Override
    public int themeColor() {
        return 0xFF2A2A;
    }
}
