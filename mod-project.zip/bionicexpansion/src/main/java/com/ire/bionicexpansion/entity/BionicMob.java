package com.ire.bionicexpansion.entity;

import com.ire.bionicexpansion.Attacks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Shared behaviour for every Bionic enemy and boss: AI goals, GeckoLib animations
 * (idle, walk, attack and a "special" move), coloured particle effects and attack helpers.
 */
public abstract class BionicMob extends Monster implements GeoEntity {
    public static final String ACTION = "action";
    public static final String SPECIAL = "special";

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    protected BionicMob(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    /** The mob's signature colour, used for its particles. */
    public int themeColor() {
        return 0xFFFFFF;
    }

    /** Name used for the model, texture and animation files. */
    public String modelName() {
        return BuiltInRegistries.ENTITY_TYPE.getKey(getType()).getPath();
    }

    // ---------- AI ----------

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        addAttackGoal();
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 12f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this, BionicMob.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** Melee by default. Ranged mobs override this. */
    protected void addAttackGoal() {
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1, true));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (tickCount % 20 == 0 && level() instanceof ServerLevel server) {
            Attacks.burst(server, new Vec3(getX(), getY(0.6), getZ()), themeColor(), 3, getBbWidth() * 0.5);
        }
    }

    // ---------- animations ----------

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        String prefix = "animation." + modelName() + ".";
        RawAnimation idle = RawAnimation.begin().thenLoop(prefix + "idle");
        RawAnimation walk = RawAnimation.begin().thenLoop(prefix + "walk");
        RawAnimation attack = RawAnimation.begin().thenPlay(prefix + "attack");
        RawAnimation special = RawAnimation.begin().thenPlay(prefix + "special");

        controllers.add(new AnimationController<>(this, "move", 5,
                state -> state.setAndContinue(state.isMoving() ? walk : idle)));
        controllers.add(new AnimationController<>(this, ACTION, 2, state -> {
            if (this.swinging) {
                return state.setAndContinue(attack);
            }
            state.getController().forceAnimationReset();
            return PlayState.STOP;
        }).triggerableAnim(SPECIAL, special));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }

    /** Plays the mob's big "special" animation on every nearby player's screen. */
    public void playSpecial() {
        triggerAnim(ACTION, SPECIAL);
    }

    // ---------- attack helpers (server side only) ----------

    public void shootAt(LivingEntity target, ItemStack look, float damage, float speed, float explosion) {
        shootTowards(new Vec3(target.getX(), target.getY(0.5), target.getZ()), look, damage, speed, explosion);
    }

    public void shootTowards(Vec3 point, ItemStack look, float damage, float speed, float explosion) {
        Attacks.shoot(this, point, look, damage, speed, explosion);
    }

    public void groundSlam(double radius, float damage, double lift) {
        playSpecial();
        Attacks.slam(this, radius, damage, lift, themeColor());
    }

    public void affectNearby(double radius, MobEffectInstance effect) {
        Attacks.affectNearby(this, radius, effect);
    }

    /** Teleports to a random safe spot near a point. */
    public boolean teleportNear(Vec3 point, double range) {
        for (int i = 0; i < 12; i++) {
            double x = point.x + (random.nextDouble() - 0.5) * 2 * range;
            double y = point.y + random.nextInt(5) - 2;
            double z = point.z + (random.nextDouble() - 0.5) * 2 * range;
            Vec3 before = position();
            if (randomTeleport(x, y, z, true)) {
                if (level() instanceof ServerLevel server) {
                    server.sendParticles(ParticleTypes.PORTAL, before.x, before.y + 1, before.z, 30, 0.4, 0.8, 0.4, 0.1);
                    Attacks.line(server, before.add(0, 1, 0), position().add(0, 1, 0), themeColor());
                    Attacks.burst(server, position().add(0, 1, 0), themeColor(), 25, 0.6);
                }
                playSound(SoundEvents.ENDERMAN_TELEPORT, 1f, 1f);
                return true;
            }
        }
        return false;
    }

    /** Teleports to just behind the target. */
    public boolean teleportBehind(LivingEntity target) {
        Vec3 look = target.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) flat = new Vec3(1, 0, 0);
        Vec3 spot = target.position().subtract(flat.normalize().scale(2.5));
        return teleportNear(spot, 1.0);
    }

    /** Rushes at the target, leaving a coloured trail. */
    public void charge(LivingEntity target, double strength) {
        Vec3 dir = target.position().subtract(position());
        if (dir.lengthSqr() < 1.0E-4) return;
        dir = dir.normalize().scale(strength);
        setDeltaMovement(dir.x, 0.25, dir.z);
        hasImpulse = true;
        playSound(SoundEvents.RAVAGER_ROAR, 0.8f, 1.8f);
        if (level() instanceof ServerLevel server) {
            Vec3 from = position().add(0, 1, 0);
            Attacks.line(server, from, from.add(dir.scale(4)), themeColor());
            server.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1, getZ(), 20, 0.4, 0.6, 0.4, 0.2);
        }
    }

    /** Lightning that looks real but does no damage and starts no fires. */
    public void visualLightning(double x, double y, double z) {
        if (!(level() instanceof ServerLevel server)) return;
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(server);
        if (bolt != null) {
            bolt.moveTo(x, y, z);
            bolt.setVisualOnly(true);
            server.addFreshEntity(bolt);
        }
    }

    /** Summons helpers next to this mob, keeping at most maxNearby of them around. */
    public void summon(EntityType<? extends Mob> type, int count, int maxNearby) {
        if (!(level() instanceof ServerLevel server)) return;
        int nearby = server.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(32), e -> e.getType() == type).size();
        LivingEntity target = getTarget();
        for (int i = 0; i < count && nearby < maxNearby; i++) {
            BlockPos pos = blockPosition().offset(random.nextInt(7) - 3, 0, random.nextInt(7) - 3);
            Mob mob = type.spawn(server, pos, MobSpawnType.MOB_SUMMONED);
            if (mob != null) {
                nearby++;
                if (target != null) mob.setTarget(target);
                Attacks.ring(server, mob.position().add(0, 0.1, 0), 1.2, themeColor(), 24);
                server.sendParticles(ParticleTypes.REVERSE_PORTAL, mob.getX(), mob.getY() + 1, mob.getZ(), 25, 0.4, 0.8, 0.4, 0.1);
            }
        }
    }

    /** Living target within range, or null. */
    protected LivingEntity targetWithin(double range) {
        LivingEntity target = getTarget();
        if (target != null && target.isAlive() && distanceTo(target) <= range) return target;
        return null;
    }
}
