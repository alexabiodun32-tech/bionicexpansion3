package com.ire.bionicexpansion.entity;

import com.ire.bionicexpansion.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Futuristic robot. Shoots energy blasts and has a recharging energy shield. Drops Bionic Alloy. */
public class BionicSoldier extends BionicMob implements RangedAttackMob {
    private static final float MAX_SHIELD = 12f;
    private float shield = MAX_SHIELD;

    public BionicSoldier(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 12;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.MOVEMENT_SPEED, 0.27)
                .add(Attributes.ATTACK_DAMAGE, 5.0)
                .add(Attributes.ARMOR, 8.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void addAttackGoal() {
        this.goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0, 30, 18f));
    }

    @Override
    public void performRangedAttack(LivingEntity target, float power) {
        shootAt(target, new ItemStack(ModItems.ENERGY_CHARGE.get()), 6f, 1.2f, 0f);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (tickCount % 40 == 0 && shield < MAX_SHIELD) {
            shield = Math.min(MAX_SHIELD, shield + 2f);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && shield > 0 && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            float absorbed = Math.min(shield, amount);
            shield -= absorbed;
            amount -= absorbed;
            if (level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(1.0), getZ(), 15, 0.4, 0.6, 0.4, 0.3);
            }
            playSound(SoundEvents.SHIELD_BLOCK, 1f, 1.5f);
            if (amount <= 0) return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.IRON_GOLEM_STEP;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.IRON_GOLEM_DEATH;
    }

    @Override
    public int themeColor() {
        return 0x3CE8FF;
    }
}
