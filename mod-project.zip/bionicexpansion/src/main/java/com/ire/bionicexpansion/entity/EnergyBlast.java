package com.ire.bionicexpansion.entity;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Fireball;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Energy blast fired by Bionic Soldiers, Aliens and the bosses. It shows as a flying item
 * (set with setItem), so the same projectile can be an energy orb or a thrown boulder.
 */
public class EnergyBlast extends Fireball {
    private float damage = 6f;
    private float explosion = 0f;

    public EnergyBlast(EntityType<? extends EnergyBlast> type, Level level) {
        super(type, level);
    }

    public void setDamage(float damage) {
        this.damage = damage;
    }

    /** Explosion power on impact (0 = none). Explosions never break blocks. */
    public void setExplosion(float power) {
        this.explosion = power;
    }

    @Override
    protected boolean shouldBurn() {
        return false;
    }

    @Override
    protected ParticleOptions getTrailParticle() {
        return ParticleTypes.ELECTRIC_SPARK;
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount > 100) {
            discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;
        Entity target = result.getEntity();
        Entity owner = getOwner();
        if (com.ire.bionicexpansion.Attacks.isFriendly(owner, target)) return;
        LivingEntity ownerLiving = owner instanceof LivingEntity living ? living : null;
        target.hurt(damageSources().mobProjectile(this, ownerLiving), damage);
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (level() instanceof ServerLevel server) {
            if (explosion > 0f) {
                server.explode(this, getX(), getY(), getZ(), explosion, Level.ExplosionInteraction.NONE);
            }
            server.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(), 10, 0.2, 0.2, 0.2, 0.2);
            discard();
        }
    }
}
