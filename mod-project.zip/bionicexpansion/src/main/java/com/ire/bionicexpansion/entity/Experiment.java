package com.ire.bionicexpansion.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

/** Failed lab experiment. Every few seconds it gets a random new ability. */
public class Experiment extends BionicMob {
    public Experiment(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 12;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if ((tickCount + getId()) % 160 != 0) return;
        LivingEntity target = getTarget();
        switch (random.nextInt(5)) {
            case 0 -> addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 140, 2));
            case 1 -> addEffect(new MobEffectInstance(MobEffects.JUMP, 140, 3));
            case 2 -> addEffect(new MobEffectInstance(MobEffects.REGENERATION, 140, 2));
            case 3 -> {
                if (target != null) teleportNear(target.position(), 4);
                else teleportNear(position(), 8);
            }
            default -> addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 140, 2));
        }
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.WITCH, getX(), getY(1.0), getZ(), 20, 0.4, 0.6, 0.4, 0.1);
        }
        playSound(SoundEvents.ZOMBIE_VILLAGER_CURE, 0.6f, 1.6f);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ZOMBIE_VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ZOMBIE_VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ZOMBIE_VILLAGER_DEATH;
    }

    @Override
    public int themeColor() {
        return 0xC43CFF;
    }
}
