package com.ire.bionicexpansion.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Fast hovering bike. Glides over water and lava, climbs blocks, steers with the mouse. */
public class Hoverbike extends VehicleEntity {
    public Hoverbike(EntityType<? extends LivingEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return vehicleAttributes(40.0, 0.42);
    }

    @Override
    protected Vec3 getRiddenInput(Player player, Vec3 travel) {
        float forward = player.zza > 0 ? player.zza : player.zza * 0.4f;
        return new Vec3(player.xxa * 0.4f, 0.0, forward);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide && isDriving()) {
            Vec3 back = Vec3.directionFromRotation(0, getYRot()).scale(-1.3);
            level().addParticle(ParticleTypes.ELECTRIC_SPARK, getX() + back.x, getY() + 0.3, getZ() + back.z, 0, 0.02, 0);
            level().addParticle(ParticleTypes.SOUL_FIRE_FLAME, getX() + back.x, getY() + 0.35, getZ() + back.z,
                    back.x * 0.05, 0, back.z * 0.05);
        }
        if (level().isClientSide && tickCount % 4 == 0) {
            level().addParticle(ParticleTypes.END_ROD, getX() + (random.nextDouble() - 0.5), getY() + 0.05,
                    getZ() + (random.nextDouble() - 0.5), 0, -0.02, 0);
        }
    }
}
