package com.ire.bionicexpansion.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Jet. Flies wherever you look while you hold W; let go of W and it hovers in place.
 * With nobody inside it drops to the ground.
 */
public class Jet extends VehicleEntity {
    public Jet(EntityType<? extends LivingEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return vehicleAttributes(60.0, 0.5);
    }

    @Override
    protected Vec3 getRiddenInput(Player player, Vec3 travel) {
        float forward = Math.max(0f, player.zza);
        double pitch = Math.toRadians(player.getXRot());
        return new Vec3(player.xxa * 0.3f, -Math.sin(pitch) * forward, Math.cos(pitch) * forward);
    }

    @Override
    protected float getFlyingSpeed() {
        return getControllingPassenger() != null ? getSpeed() * 0.25f : 0.02f;
    }

    @Override
    public void tick() {
        boolean flying = isVehicle();
        if (isNoGravity() != flying) {
            setNoGravity(flying);
        }
        if (flying && !onGround()) {
            // gently slow down vertical drift so it hovers when you let go
            Vec3 m = getDeltaMovement();
            setDeltaMovement(m.x, m.y * 0.9, m.z);
        }
        super.tick();
        if (level().isClientSide && isVehicle()) {
            Vec3 back = Vec3.directionFromRotation(0, getYRot()).scale(-1.9);
            boolean fast = getDeltaMovement().lengthSqr() > 0.05;
            level().addParticle(fast ? ParticleTypes.FLAME : ParticleTypes.SMOKE,
                    getX() + back.x, getY() + 0.45, getZ() + back.z, back.x * 0.05, 0, back.z * 0.05);
            if (fast) {
                level().addParticle(ParticleTypes.ELECTRIC_SPARK, getX() + back.x, getY() + 0.45, getZ() + back.z, 0, 0, 0);
            }
        }
    }
}
