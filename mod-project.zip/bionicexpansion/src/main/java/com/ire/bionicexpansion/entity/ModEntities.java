package com.ire.bionicexpansion.entity;

import com.ire.bionicexpansion.BionicExpansion;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, BionicExpansion.MODID);

    // Enemies (hitbox width, height in blocks; matches the 3D models)
    public static final DeferredHolder<EntityType<?>, EntityType<MutantZombie>> MUTANT_ZOMBIE =
            mob("mutant_zombie", MutantZombie::new, 0.9f, 2.2f, false, 10);
    public static final DeferredHolder<EntityType<?>, EntityType<BionicSoldier>> BIONIC_SOLDIER =
            mob("bionic_soldier", BionicSoldier::new, 0.7f, 2.0f, false, 10);
    public static final DeferredHolder<EntityType<?>, EntityType<Alien>> ALIEN =
            mob("alien", Alien::new, 0.7f, 2.3f, false, 10);
    public static final DeferredHolder<EntityType<?>, EntityType<SpeedDemon>> SPEED_DEMON =
            mob("speed_demon", SpeedDemon::new, 0.7f, 2.0f, true, 10);
    public static final DeferredHolder<EntityType<?>, EntityType<Titan>> TITAN =
            mob("titan", Titan::new, 1.6f, 2.8f, false, 12);
    public static final DeferredHolder<EntityType<?>, EntityType<Experiment>> EXPERIMENT =
            mob("experiment", Experiment::new, 0.8f, 2.1f, false, 10);

    // Bosses
    public static final DeferredHolder<EntityType<?>, EntityType<BionicGuardian>> BIONIC_GUARDIAN =
            mob("bionic_guardian", BionicGuardian::new, 2.0f, 3.6f, true, 16);
    public static final DeferredHolder<EntityType<?>, EntityType<AlienKing>> ALIEN_KING =
            mob("alien_king", AlienKing::new, 1.2f, 3.2f, true, 16);
    public static final DeferredHolder<EntityType<?>, EntityType<SpeedDemonBoss>> SPEED_DEMON_BOSS =
            mob("speed_demon_boss", SpeedDemonBoss::new, 1.2f, 2.9f, true, 16);
    public static final DeferredHolder<EntityType<?>, EntityType<TitanBoss>> TITAN_BOSS =
            mob("titan_boss", TitanBoss::new, 3.0f, 4.6f, true, 16);
    public static final DeferredHolder<EntityType<?>, EntityType<QuantumEntity>> QUANTUM_ENTITY =
            mob("quantum_entity", QuantumEntity::new, 1.6f, 3.8f, true, 16);
    public static final DeferredHolder<EntityType<?>, EntityType<QuantumClone>> QUANTUM_CLONE =
            mob("quantum_clone", QuantumClone::new, 1.0f, 2.4f, true, 10);

    // Vehicles
    public static final DeferredHolder<EntityType<?>, EntityType<Hoverbike>> HOVERBIKE =
            ENTITIES.register("hoverbike", () -> EntityType.Builder.<Hoverbike>of(Hoverbike::new, MobCategory.MISC)
                    .sized(1.3f, 0.85f).fireImmune().clientTrackingRange(10).build("hoverbike"));
    public static final DeferredHolder<EntityType<?>, EntityType<Jet>> JET =
            ENTITIES.register("jet", () -> EntityType.Builder.<Jet>of(Jet::new, MobCategory.MISC)
                    .sized(2.4f, 1.1f).fireImmune().clientTrackingRange(16).build("jet"));

    // Projectile
    public static final DeferredHolder<EntityType<?>, EntityType<EnergyBlast>> ENERGY_BLAST =
            ENTITIES.register("energy_blast", () -> EntityType.Builder.<EnergyBlast>of(EnergyBlast::new, MobCategory.MISC)
                    .sized(0.5f, 0.5f)
                    .clientTrackingRange(8)
                    .updateInterval(2)
                    .build("energy_blast"));

    private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> mob(
            String name, EntityType.EntityFactory<T> factory, float width, float height, boolean fireImmune, int trackingRange) {
        return ENTITIES.register(name, () -> {
            EntityType.Builder<T> builder = EntityType.Builder.of(factory, MobCategory.MONSTER)
                    .sized(width, height)
                    .clientTrackingRange(trackingRange);
            if (fireImmune) {
                builder = builder.fireImmune();
            }
            return builder.build(name);
        });
    }
}
