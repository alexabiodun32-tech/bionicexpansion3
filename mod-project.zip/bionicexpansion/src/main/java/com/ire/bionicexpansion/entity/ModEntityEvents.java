package com.ire.bionicexpansion.entity;

import com.ire.bionicexpansion.BionicExpansion;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

/** Mod-bus setup: health/speed/damage stats and where the enemies can spawn. */
@EventBusSubscriber(modid = BionicExpansion.MODID, bus = EventBusSubscriber.Bus.MOD)
public class ModEntityEvents {

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.MUTANT_ZOMBIE.get(), MutantZombie.createAttributes().build());
        event.put(ModEntities.BIONIC_SOLDIER.get(), BionicSoldier.createAttributes().build());
        event.put(ModEntities.ALIEN.get(), Alien.createAttributes().build());
        event.put(ModEntities.SPEED_DEMON.get(), SpeedDemon.createAttributes().build());
        event.put(ModEntities.TITAN.get(), Titan.createAttributes().build());
        event.put(ModEntities.EXPERIMENT.get(), Experiment.createAttributes().build());
        event.put(ModEntities.BIONIC_GUARDIAN.get(), BionicGuardian.createAttributes().build());
        event.put(ModEntities.ALIEN_KING.get(), AlienKing.createAttributes().build());
        event.put(ModEntities.SPEED_DEMON_BOSS.get(), SpeedDemonBoss.createAttributes().build());
        event.put(ModEntities.TITAN_BOSS.get(), TitanBoss.createAttributes().build());
        event.put(ModEntities.QUANTUM_ENTITY.get(), QuantumEntity.createAttributes().build());
        event.put(ModEntities.QUANTUM_CLONE.get(), QuantumClone.createAttributes().build());
        event.put(ModEntities.HOVERBIKE.get(), Hoverbike.createAttributes().build());
        event.put(ModEntities.JET.get(), Jet.createAttributes().build());
    }

    @SubscribeEvent
    public static void spawnPlacements(RegisterSpawnPlacementsEvent event) {
        ground(event, ModEntities.MUTANT_ZOMBIE.get());
        ground(event, ModEntities.BIONIC_SOLDIER.get());
        ground(event, ModEntities.ALIEN.get());
        ground(event, ModEntities.SPEED_DEMON.get());
        ground(event, ModEntities.TITAN.get());
        ground(event, ModEntities.EXPERIMENT.get());
        // bosses can very rarely appear in the wild in their home biomes
        ground(event, ModEntities.BIONIC_GUARDIAN.get());
        ground(event, ModEntities.ALIEN_KING.get());
        ground(event, ModEntities.SPEED_DEMON_BOSS.get());
        ground(event, ModEntities.TITAN_BOSS.get());
    }

    private static <T extends Monster> void ground(RegisterSpawnPlacementsEvent event, EntityType<T> type) {
        event.register(type, SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkMonsterSpawnRules, RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }
}
