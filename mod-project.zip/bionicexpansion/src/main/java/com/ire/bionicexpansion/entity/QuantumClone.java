package com.ire.bionicexpansion.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

/** Short-lived copy made by the Quantum Entity. Hits hard, dies fast, vanishes after 20 seconds. */
public class QuantumClone extends BionicMob {
    public QuantumClone(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 10.0)
                .add(Attributes.MOVEMENT_SPEED, 0.34)
                .add(Attributes.ATTACK_DAMAGE, 8.0)
                .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (tickCount > 400) {
            if (level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.REVERSE_PORTAL, getX(), getY(1.0), getZ(), 30, 0.4, 0.8, 0.4, 0.1);
            }
            discard();
        }
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENDERMAN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDERMAN_TELEPORT;
    }

    @Override
    public int themeColor() {
        return 0x7A5CFF;
    }
}
