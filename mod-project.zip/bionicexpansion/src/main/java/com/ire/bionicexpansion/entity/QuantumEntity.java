package com.ire.bionicexpansion.entity;

import com.ire.bionicexpansion.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * FINAL BOSS - The Quantum Entity. Three phases. Teleports, flips gravity, makes clones,
 * scrambles the arena, opens portals and fires huge energy attacks. Drops the Quantum Heart.
 */
public class QuantumEntity extends BionicBoss {
    private Vec3 portal = null;
    private int portalTicks = 0;

    public QuantumEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level, BossEvent.BossBarColor.PURPLE);
        this.xpReward = 1000;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 800.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 18.0)
                .add(Attributes.ARMOR, 14.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.STEP_HEIGHT, 1.2);
    }

    @Override
    protected float[] phaseThresholds() {
        return new float[]{0.66f, 0.33f};
    }

    @Override
    protected void onPhaseChange(int newPhase) {
        super.onPhaseChange(newPhase);
        if (newPhase == 2) announce("Reality is bending. The Quantum Entity splits itself apart!");
        if (newPhase == 3) announce("FINAL PHASE. The Quantum Entity tears open the arena!");
        for (int i = 0; i < 4; i++) {
            visualLightning(getX() + random.nextInt(13) - 6, getY(), getZ() + random.nextInt(13) - 6);
        }
    }

    @Override
    protected void bossTick(LivingEntity target) {
        tickPortal();
        if (target == null) return;
        int p = phase();
        ItemStack orb = new ItemStack(ModItems.QUANTUM_HEART.get());

        // Energy attacks
        if (every(p == 1 ? 50 : p == 2 ? 35 : 22) && hasLineOfSight(target)) {
            shootAt(target, orb, 9f, 1.5f, p >= 2 ? 1.5f : 0f);
        }
        // Ring of blasts in phase 3
        if (p >= 3 && every(140)) {
            for (int i = 0; i < 10; i++) {
                double angle = Math.PI * 2 * i / 10;
                shootTowards(position().add(Math.cos(angle) * 10, 1.5, Math.sin(angle) * 10), orb, 8f, 1.2f, 0f);
            }
        }
        // Teleport
        if (every(p == 1 ? 120 : p == 2 ? 80 : 50)) {
            if (random.nextBoolean()) teleportBehind(target);
            else teleportNear(target.position(), 8);
        }
        // Gravity manipulation: float everyone up, or drag them in
        if (every(p == 1 ? 220 : 160)) {
            if (random.nextBoolean()) {
                affectNearby(16, new MobEffectInstance(MobEffects.LEVITATION, 50, 1));
                announce("Gravity reverses!");
            } else {
                pullNearby(16);
            }
        }
        // Clones from phase 2
        if (p >= 2 && every(p == 2 ? 300 : 220)) {
            summon(ModEntities.QUANTUM_CLONE.get(), 2, 6);
        }
        // Change the arena: darkness and everyone gets scattered
        if (p >= 2 && every(p == 2 ? 400 : 260)) {
            scrambleArena();
        }
        // Portals
        if (every(p == 1 ? 200 : 140) && portal == null) {
            portal = target.position();
            portalTicks = 30;
            playSound(SoundEvents.PORTAL_TRIGGER, 1f, 0.8f);
        }
    }

    private void pullNearby(double radius) {
        if (!(level() instanceof ServerLevel server)) return;
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(radius),
                x -> x != this && !(x instanceof BionicMob))) {
            Vec3 pull = position().subtract(e.position());
            if (pull.lengthSqr() < 1.0E-4) continue;
            pull = pull.normalize().scale(1.6);
            e.setDeltaMovement(pull.x, 0.4, pull.z);
            e.hurtMarked = true;
        }
        playSound(SoundEvents.WARDEN_SONIC_BOOM, 1.5f, 0.6f);
    }

    private void scrambleArena() {
        if (!(level() instanceof ServerLevel server)) return;
        announce("The Quantum Entity rewrites the arena!");
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(24),
                x -> x != this && !(x instanceof BionicMob))) {
            e.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 0));
            for (int i = 0; i < 10; i++) {
                double x = getX() + random.nextInt(21) - 10;
                double z = getZ() + random.nextInt(21) - 10;
                if (e.randomTeleport(x, getY() + random.nextInt(5) - 2, z, true)) break;
            }
        }
        for (int i = 0; i < 6; i++) {
            visualLightning(getX() + random.nextInt(25) - 12, getY(), getZ() + random.nextInt(25) - 12);
        }
    }

    private void tickPortal() {
        if (portal == null || !(level() instanceof ServerLevel server)) return;
        server.sendParticles(ParticleTypes.REVERSE_PORTAL, portal.x, portal.y + 0.1, portal.z, 25, 1.5, 0.05, 1.5, 0.02);
        if (--portalTicks > 0) return;
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class,
                new AABB(portal.x - 2, portal.y - 1, portal.z - 2, portal.x + 2, portal.y + 2, portal.z + 2),
                x -> !(x instanceof BionicMob))) {
            e.teleportTo(e.getX() + random.nextInt(11) - 5, e.getY() + 14, e.getZ() + random.nextInt(11) - 5);
            e.hurtMarked = true;
        }
        server.sendParticles(ParticleTypes.PORTAL, portal.x, portal.y + 1, portal.z, 100, 1, 1, 1, 0.6);
        playSound(SoundEvents.ENDERMAN_TELEPORT, 2f, 0.5f);
        portal = null;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WARDEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WARDEN_DEATH;
    }

    @Override
    public int themeColor() {
        return 0x3CE8FF;
    }
}
