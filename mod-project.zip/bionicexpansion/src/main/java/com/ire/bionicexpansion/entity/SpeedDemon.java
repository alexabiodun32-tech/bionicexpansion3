package com.ire.bionicexpansion.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Extremely fast, charges at you and dodges attacks. Drops Speed Core. */
public class SpeedDemon extends BionicMob {
    public SpeedDemon(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 15;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 26.0)
                .add(Attributes.MOVEMENT_SPEED, 0.42)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        LivingEntity target = targetWithin(14);
        if (target != null && (tickCount + getId()) % 60 == 0 && onGround()) {
            charge(target, 1.4);
        }
    }

    /** 25% chance to sidestep a hit. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && source.getEntity() != null && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                && random.nextFloat() < 0.25f) {
            dodge();
            return false;
        }
        return super.hurt(source, amount);
    }

    protected void dodge() {
        Vec3 look = getLookAngle();
        Vec3 side = new Vec3(-look.z, 0, look.x);
        if (side.lengthSqr() < 1.0E-4) side = new Vec3(1, 0, 0);
        side = side.normalize().scale(random.nextBoolean() ? 1.0 : -1.0);
        setDeltaMovement(side.x, 0.3, side.z);
        hasImpulse = true;
        playSound(SoundEvents.PHANTOM_FLAP, 1f, 2f);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.BLAZE_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.BLAZE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.BLAZE_DEATH;
    }

    @Override
    public int themeColor() {
        return 0xFFD23C;
    }
}
