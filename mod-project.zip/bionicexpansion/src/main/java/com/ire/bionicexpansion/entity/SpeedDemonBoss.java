package com.ire.bionicexpansion.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * BOSS 3 - The Speed Demon. Lightning-fast charges, teleports behind you, shockwaves,
 * and freezes everything nearby. Drops the Speed Demon Core and Speed Cores.
 */
public class SpeedDemonBoss extends BionicBoss {
    public SpeedDemonBoss(EntityType<? extends Monster> type, Level level) {
        super(type, level, BossEvent.BossBarColor.YELLOW);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 260.0)
                .add(Attributes.MOVEMENT_SPEED, 0.48)
                .add(Attributes.ATTACK_DAMAGE, 12.0)
                .add(Attributes.ARMOR, 6.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    protected float[] phaseThresholds() {
        return new float[]{0.5f};
    }

    @Override
    protected void bossTick(LivingEntity target) {
        if (target == null) return;
        boolean angry = phase() >= 2;
        if (every(angry ? 30 : 45) && distanceTo(target) < 18) {
            charge(target, angry ? 2.2 : 1.8);
            visualLightning(getX(), getY(), getZ());
        }
        if (every(angry ? 70 : 100)) {
            teleportBehind(target);
        }
        if (every(angry ? 100 : 140) && distanceTo(target) < 8) {
            groundSlam(7, 9f, 0.6);
        }
        if (every(angry ? 180 : 240)) {
            affectNearby(10, new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 5));
            affectNearby(10, new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 60, 2));
            announce("The Speed Demon freezes time around you!");
            playSound(SoundEvents.BEACON_DEACTIVATE, 2f, 0.6f);
        }
    }

    /** Dodges 30% of hits. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && source.getEntity() != null && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                && random.nextFloat() < 0.3f) {
            Vec3 look = getLookAngle();
            Vec3 side = new Vec3(-look.z, 0, look.x);
            if (side.lengthSqr() < 1.0E-4) side = new Vec3(1, 0, 0);
            side = side.normalize().scale(random.nextBoolean() ? 1.3 : -1.3);
            setDeltaMovement(side.x, 0.3, side.z);
            hasImpulse = true;
            playSound(SoundEvents.PHANTOM_FLAP, 1.5f, 2f);
            return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.BLAZE_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.BLAZE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.BLAZE_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 0.6f;
    }

    @Override
    public int themeColor() {
        return 0xFF3C1A;
    }
}
