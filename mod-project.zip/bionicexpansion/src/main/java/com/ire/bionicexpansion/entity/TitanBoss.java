package com.ire.bionicexpansion.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/**
 * BOSS 4 - The Titan. Massive punches, ground shockwaves, throws boulders, summons robots,
 * and speeds up in phase 2. Drops the Titan Core.
 */
public class TitanBoss extends BionicBoss {
    public TitanBoss(EntityType<? extends Monster> type, Level level) {
        super(type, level, BossEvent.BossBarColor.WHITE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 500.0)
                .add(Attributes.MOVEMENT_SPEED, 0.22)
                .add(Attributes.ATTACK_DAMAGE, 24.0)
                .add(Attributes.ATTACK_KNOCKBACK, 3.0)
                .add(Attributes.ARMOR, 16.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.STEP_HEIGHT, 1.6);
    }

    @Override
    protected float[] phaseThresholds() {
        return new float[]{0.4f};
    }

    @Override
    protected void onPhaseChange(int newPhase) {
        super.onPhaseChange(newPhase);
        announce("The Titan's core goes critical. It's getting faster!");
    }

    @Override
    protected void bossTick(LivingEntity target) {
        boolean angry = phase() >= 2;
        if (angry && tickCount % 40 == 0) {
            addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 2, false, false));
        }
        if (target == null) return;

        if (every(angry ? 70 : 100) && distanceTo(target) < 10 && onGround()) {
            groundSlam(10, angry ? 16f : 12f, 0.9);
        }
        if (every(angry ? 40 : 60) && distanceTo(target) > 5 && hasLineOfSight(target)) {
            ItemStack boulder = new ItemStack(random.nextBoolean() ? Items.COBBLESTONE : Items.IRON_BLOCK);
            shootAt(target, boulder, angry ? 14f : 10f, 1.0f, 0f);
            playSound(SoundEvents.IRON_GOLEM_ATTACK, 2f, 0.6f);
        }
        if (every(angry ? 280 : 400)) {
            summon(ModEntities.BIONIC_SOLDIER.get(), 3, 6);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.RAVAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.IRON_GOLEM_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 0.4f;
    }

    @Override
    public int themeColor() {
        return 0xFF5A00;
    }
}
